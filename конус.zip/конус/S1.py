import math

R = 4  
l = 7  
S_бок = math.pi * R * l

print(f"Sбок = {R*l}π ≈ {S_бок:.2f} см²")