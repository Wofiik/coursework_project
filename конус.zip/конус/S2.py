import math

R = 3  
l = 8  
S_poln = math.pi * R * (l + R)
print(f"Ответ: {R * (l+R)}π см² (≈ {S_poln:.2f} см²)")