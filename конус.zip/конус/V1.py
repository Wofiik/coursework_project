import math

R = 6  
h = 10 
V = (1/3) * math.pi * R**2 * h
print(f"\nОтвет: {R**2 * h / 3}π см³ (≈ {V:.2f} см³)")