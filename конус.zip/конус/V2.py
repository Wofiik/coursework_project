import math

V = 50 * math.pi 
R = 5     
h = (3 * V) / (math.pi * R**2)
print(f"\nОтвет: {h:.0f} см")