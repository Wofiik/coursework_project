import math
# Дано
d = 3 * math.sqrt(2)  
# Решение
# P = 6√2 × d
P = 6 * math.sqrt(2) * d
print(f"\nОтвет: {6 * 3 * 2:.0f} см")
