import math
# Дано
k = 3  
D = k * math.sqrt(3)  
# Решение
# P = 4√3 × D
P = 4 * math.sqrt(3) * D
print(f"\nОтвет: {4 * k * 3:.0f} см")
