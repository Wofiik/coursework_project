import math
# Дано
V = 216  
# Решение
a = V ** (1/3)  
P = 12 * a      
print(f"\nОтвет: {P:.0f} см")
