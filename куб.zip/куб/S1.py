import math

# Дано
S = 150  

# Решение
# S = 6 * a²
# a² = S / 6
a_squared = S / 6

# a = √(S/6)
a = math.sqrt(a_squared)

# Вывод результата
print(f"Площадь поверхности куба: {S} см²")
print(f"Ребро куба: {a} см")
