import math
# Дано
S_full = 150  

# S = 6a²
# a² = S / 6
a_squared = S_full / 6

# S_бок = 4a²
S_lateral = 4 * a_squared

# Вывод результата
print(f"\nОтвет: {S_lateral} см²")
