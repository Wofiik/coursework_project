import math

# Дано
S = 294  

# S = 3d²
# d² = S / 3
d_squared = S / 3

# d = √(S/3)
d = math.sqrt(d_squared)

# Представление в виде 7√2
sqrt2 = math.sqrt(2)
print(f"\nОтвет: 7√2 см")
