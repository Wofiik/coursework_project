import math

# Дано
S = 216  
# S = 2D²
# D² = S / 2
D_squared = S / 2

# D = √(S/2)
D = math.sqrt(D_squared)
print(f"\nОтвет: 6√3 см")
