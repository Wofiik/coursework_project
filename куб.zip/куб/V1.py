import math
# Дано
V = 343  
# Решение
a = V ** (1/3)  
print(f"\nОтвет: {a:.0f} см")
