import math
# Дано
k = 9  
d = k * math.sqrt(2)  
# Решение
a = d / math.sqrt(2)  
V = a ** 3           
print(f"\nОтвет: {V:.0f} см³")
