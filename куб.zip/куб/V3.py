import math
# Дано
D = 12  
# Решение
a = D / math.sqrt(3) 
V = a ** 3   
print(f"\nОтвет: 192√3 см³ ≈ {V:.2f} см³")
