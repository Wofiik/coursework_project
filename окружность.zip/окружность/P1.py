import math

P = 12 * math.pi  # длина окружности = 12π см
R = P / (2 * math.pi)

print(f"Радиус окружности: {R} см")