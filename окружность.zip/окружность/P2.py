import math

P = 15 * 3.14
D = P / 3.14

print(f"Диаметр окружности: {int(D)} см")