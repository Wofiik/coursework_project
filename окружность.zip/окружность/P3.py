import math

S = 25 * math.pi   # площадь круга
L = 2 * math.pi * math.sqrt(S / math.pi)

print(f"Длинна окружности: {L:.2f} см")