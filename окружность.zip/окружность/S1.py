import math

S = 64 * math.pi 
R = math.sqrt(S / math.pi)

print(f"Радиус круга: {int(R)} м")