import math

S = 25 * math.pi  
D = math.sqrt(4 * S / math.pi)

print(f"Диаметр круга: {int(D)} см")