import math

L = 10 * math.pi  
S = L**2 / (4 * math.pi)

print(f"Площадь круга: {int(S / math.pi)}π см²")