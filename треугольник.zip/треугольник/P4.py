def triangle_area_from_perimeter_and_inradius(perimeter, inradius):

    return (perimeter * inradius) / 2

area = triangle_area_from_perimeter_and_inradius(40, 5)
print(f"Площадь треугольника: {area} см²")