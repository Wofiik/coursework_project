import math

# Исходные данные
perimeter = 36
ratio = [3, 4, 5]

# 1. Находим сумму частей отношения
sum_of_parts = sum(ratio)

# 2. Вычисляем коэффициент пропорциональности (длину одной части)
# Так как периметр = 3x + 4x + 5x = 12x, то x = perimeter / sum_of_parts
x = perimeter / sum_of_parts

# 3. Находим длины сторон
sides = [part * x for part in ratio]
a, b, c = sides[0], sides[1], sides[2]

print(f"Стороны треугольника: {a} см, {b} см, {c} см")

# 4. Вычисляем полупериметр
p = perimeter / 2
print(f"Полупериметр (p): {p} см")

# 5. Применяем формулу Герона: S = sqrt(p * (p - a) * (p - b) * (p - c))
# Используем формулу Герона для нахождения площади
area_squared = p * (p - a) * (p - b) * (p - c)
area = math.sqrt(area_squared)

print(f"Площадь треугольника (по формуле Герона): {area} см²")

# Дополнительно: проверим, является ли треугольник прямоугольным (3:4:5 - классика)
if a**2 + b**2 == c**2:
    area_alt = (a * b) / 2
    print(f"Площадь через катеты: {area_alt} см²")