import math

# Дано
R = 4  
# Решение
S = 4 * math.pi * R ** 2
print(f"\nОтвет: {4 * R**2}π см² ≈ {S:.2f} см²")
