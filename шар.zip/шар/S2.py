import math

# Дано
D = 14  
# Решение
S = math.pi * D ** 2
print(f"\nОтвет: {D**2}π см² ≈ {S:.2f} см²")
