import math

# Дано
R = 1  
# Решение
V = (4/3) * math.pi * R ** 3
print(f"\nОтвет: {V:.2f} см³")
