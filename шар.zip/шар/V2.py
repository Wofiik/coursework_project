import math

# Дано
D = 12 
# Решение
V = (math.pi * D ** 3) / 6
print(f"\nОтвет: {D**3/6}π см³ ≈ {V:.2f} см³")
